create view woman_user as
select `test`.`ib_user`.`id`        AS `id`,
       `test`.`ib_user`.`account`   AS `account`,
       `test`.`ib_user`.`user_name` AS `user_name`,
       `test`.`ib_user`.`sex`       AS `sex`
from `test`.`ib_user`
where (`test`.`ib_user`.`sex` = 0);

